﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace CoffeeShop
{
    public partial class EmployeeDetails : Form
    {

        public EmployeeDetails()
        {
            InitializeComponent();
        }
        
       
        private void EmployeeDetails_Load(object sender, EventArgs e)
        {
            GetEmployeeRecord();
        }

        private void GetEmployeeRecord()
        {
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Test_Demo"].ConnectionString);
            connection.Open();

            SqlCommand cmd = new SqlCommand("Select * from Employee", connection);
            DataTable dt = new DataTable();


            SqlDataReader Sdr = cmd.ExecuteReader(); 
            dt.Load(Sdr);
            connection.Close();

            EmployeedataGridView.DataSource = dt;
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ButtonInsert_Click(object sender, EventArgs e)
        {
            if (textId.Text == "")
            {
                MessageBox.Show("Id can not be empty");

            }
            else if (textName.Text == "")
            {
                MessageBox.Show("Name can not be empty");
            }
            else if (textPass.Text == "")
            {
                MessageBox.Show("Give an Password");
            }
            else
            {

                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Test_Demo"].ConnectionString);
                connection.Open();
                string sql = "INSERT INTO Employee(Id,name,Gender,dob,address,PhoneNo,password) VALUES('" + Convert.ToInt32(textId.Text) + "','" + textName.Text + "','" + comboGender.Text + "','" + dateTimeDob.Text + "','" + textAddres.Text + "','" + Convert.ToInt32(textPhn.Text) + "','" + textPass.Text + "')";
                SqlCommand command = new SqlCommand(sql, connection);
                int result = command.ExecuteNonQuery();
                //SqlCommand cmd = new SqlCommand("INSERT INTO Employee(Id,name,Gender,dob,address,PhoneNo,password) VALUES('" + Convert.ToInt32(textId.Text) + "','" + textName.Text + "','" + comboGender.Text + "','" + dateTimeDob.Text + "','" + textAddres.Text + "','" + Convert.ToInt32(textPhn.Text) + "','" + textPass.Text + "')");
                if (result > 0)
                {
                    MessageBox.Show("User Added");
                }
                else
                {
                    MessageBox.Show("Error");
                }

                GetEmployeeRecord();
                ResetFormControls();

            }
        }

        

        private void buttonBack_Click(object sender, EventArgs e)
        {
            OwnerHome f1 = new OwnerHome();
            f1.Show();
            this.Hide();
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            ResetFormControls();
        }

        private void ResetFormControls()
        {
            textId.Clear();
            textName.Clear();
            comboGender.Text = "";
            textAddres.Clear();
            textPhn.Clear();
            textPass.Clear();
            dateTimeDob.Clear();
            textId.Focus();
        }
        
        private void EmployeedataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textId.Text = EmployeedataGridView.SelectedRows[0].Cells[0].Value.ToString();
            textName.Text = EmployeedataGridView.SelectedRows[0].Cells[1].Value.ToString();
            comboGender.Text = EmployeedataGridView.SelectedRows[0].Cells[2].Value.ToString();
            dateTimeDob.Text = EmployeedataGridView.SelectedRows[0].Cells[3].Value.ToString();
            textAddres.Text = EmployeedataGridView.SelectedRows[0].Cells[4].Value.ToString();
            textPhn.Text = EmployeedataGridView.SelectedRows[0].Cells[5].Value.ToString();
            textPass.Text = EmployeedataGridView.SelectedRows[0].Cells[6].Value.ToString();

        }
        

        private void buttonUpate_Click(object sender, EventArgs e)
        {
            if(textId.Text != "")
            {
                { 
                //SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Test_Demo"].ConnectionString);
                //connection.Open();
                //SqlCommand cmd = new SqlCommand("UPDATE Employee SET name='Sami' WHERE Id =" + Convert.ToInt32(textId.Text), connection);


                //cmd.ExecuteNonQuery();
                //connection.Close();

                //MessageBox.Show("Employee is Updated from the system");

                //GetEmployeeRecord();
                //ResetFormControls();
            }
        }
            else
            {
                MessageBox.Show("Please Select a Employee to Update his information");
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (textId.Text != "")
            {
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Test_Demo"].ConnectionString);
                connection.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM Employee WHERE Id ="+Convert.ToInt32(textId.Text), connection);
                

                cmd.ExecuteNonQuery();
                connection.Close();

                MessageBox.Show("Employee is Deleted from the system");

                GetEmployeeRecord();
                ResetFormControls();
            }
            else
            {
                MessageBox.Show("Please Select a Employee to Delete his information");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void EmployeedataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
