﻿namespace CoffeeShop
{
    partial class bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(bill));
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonBack = new System.Windows.Forms.Button();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.textAffogato = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.textFlat = new System.Windows.Forms.TextBox();
            this.textMochaccino = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textIrish = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textEspresso = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textFilter = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textCappuchino = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textLatte = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.cheAffogato = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cheMochaccion = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.cheFlat = new System.Windows.Forms.CheckBox();
            this.cheIrish = new System.Windows.Forms.CheckBox();
            this.cheEspresso = new System.Windows.Forms.CheckBox();
            this.cheFilter = new System.Windows.Forms.CheckBox();
            this.cheCappuccino = new System.Windows.Forms.CheckBox();
            this.cheLatte = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textFrenchFries = new System.Windows.Forms.TextBox();
            this.cheFrencFries = new System.Windows.Forms.CheckBox();
            this.textNachos = new System.Windows.Forms.TextBox();
            this.cheCrispyBurger = new System.Windows.Forms.CheckBox();
            this.textClubSandwich = new System.Windows.Forms.TextBox();
            this.textChickenFry = new System.Windows.Forms.TextBox();
            this.cheClubSandwich = new System.Windows.Forms.CheckBox();
            this.textCrispyBurger = new System.Windows.Forms.TextBox();
            this.cheBbqBurger = new System.Windows.Forms.CheckBox();
            this.textCheeseSandwich = new System.Windows.Forms.TextBox();
            this.cheNachos = new System.Windows.Forms.CheckBox();
            this.textDelightBurger = new System.Windows.Forms.TextBox();
            this.cheChickenDelighitBurger = new System.Windows.Forms.CheckBox();
            this.textBoxBbqBurger = new System.Windows.Forms.TextBox();
            this.cheChickenFry = new System.Windows.Forms.CheckBox();
            this.cheCheeseSandwich = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.labelService = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelCostOthers = new System.Windows.Forms.Label();
            this.labelCostDrinks = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.labelSubTotal = new System.Windows.Forms.Label();
            this.labelTax = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.printToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.copyToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pasteToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.helpToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.rtfReceipt = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonRest = new System.Windows.Forms.Button();
            this.buttonReceipt = new System.Windows.Forms.Button();
            this.buttonTotal = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.buttonBack);
            this.panel1.Controls.Add(this.lblTime);
            this.panel1.Controls.Add(this.lblDate);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(6, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(999, 85);
            this.panel1.TabIndex = 0;
            // 
            // buttonBack
            // 
            this.buttonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBack.Location = new System.Drawing.Point(8, 6);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(50, 24);
            this.buttonBack.TabIndex = 4;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(907, 68);
            this.lblTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(41, 13);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "label6";
            this.lblTime.Click += new System.EventHandler(this.lblTime_Click);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(11, 68);
            this.lblDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(41, 13);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "label5";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(301, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(372, 79);
            this.label1.TabIndex = 0;
            this.label1.Text = "Billing System";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.textAffogato);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.textFlat);
            this.panel2.Controls.Add(this.textMochaccino);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.textIrish);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.textEspresso);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.textFilter);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.textCappuchino);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.textLatte);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.cheAffogato);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.cheMochaccion);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.cheFlat);
            this.panel2.Controls.Add(this.cheIrish);
            this.panel2.Controls.Add(this.cheEspresso);
            this.panel2.Controls.Add(this.cheFilter);
            this.panel2.Controls.Add(this.cheCappuccino);
            this.panel2.Controls.Add(this.cheLatte);
            this.panel2.Location = new System.Drawing.Point(6, 95);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(357, 297);
            this.panel2.TabIndex = 1;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label34.Location = new System.Drawing.Point(266, 11);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(86, 24);
            this.label34.TabIndex = 3;
            this.label34.Text = "Quantity";
            // 
            // textAffogato
            // 
            this.textAffogato.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textAffogato.Location = new System.Drawing.Point(286, 262);
            this.textAffogato.Multiline = true;
            this.textAffogato.Name = "textAffogato";
            this.textAffogato.Size = new System.Drawing.Size(42, 28);
            this.textAffogato.TabIndex = 1;
            this.textAffogato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textAffogato.Click += new System.EventHandler(this.textAffogato_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label32.Location = new System.Drawing.Point(201, 11);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(58, 24);
            this.label32.TabIndex = 3;
            this.label32.Text = "Price";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label33.Location = new System.Drawing.Point(20, 14);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(125, 24);
            this.label33.TabIndex = 3;
            this.label33.Text = "Coffees Item";
            // 
            // textFlat
            // 
            this.textFlat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFlat.Location = new System.Drawing.Point(286, 229);
            this.textFlat.Multiline = true;
            this.textFlat.Name = "textFlat";
            this.textFlat.Size = new System.Drawing.Size(42, 28);
            this.textFlat.TabIndex = 1;
            this.textFlat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textFlat.Click += new System.EventHandler(this.textFlat_Click);
            // 
            // textMochaccino
            // 
            this.textMochaccino.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMochaccino.Location = new System.Drawing.Point(286, 133);
            this.textMochaccino.Multiline = true;
            this.textMochaccino.Name = "textMochaccino";
            this.textMochaccino.Size = new System.Drawing.Size(42, 28);
            this.textMochaccino.TabIndex = 1;
            this.textMochaccino.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textMochaccino.Click += new System.EventHandler(this.textMochaccino_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(214, 262);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(32, 24);
            this.label31.TabIndex = 2;
            this.label31.Text = "90";
            // 
            // textIrish
            // 
            this.textIrish.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textIrish.Location = new System.Drawing.Point(286, 197);
            this.textIrish.Multiline = true;
            this.textIrish.Name = "textIrish";
            this.textIrish.Size = new System.Drawing.Size(42, 28);
            this.textIrish.TabIndex = 1;
            this.textIrish.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textIrish.Click += new System.EventHandler(this.textIrish_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(214, 198);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(32, 24);
            this.label30.TabIndex = 2;
            this.label30.Text = "70";
            // 
            // textEspresso
            // 
            this.textEspresso.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEspresso.Location = new System.Drawing.Point(286, 102);
            this.textEspresso.Multiline = true;
            this.textEspresso.Name = "textEspresso";
            this.textEspresso.Size = new System.Drawing.Size(42, 28);
            this.textEspresso.TabIndex = 1;
            this.textEspresso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textEspresso.Click += new System.EventHandler(this.textEspresso_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(214, 230);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(32, 24);
            this.label29.TabIndex = 2;
            this.label29.Text = "70";
            // 
            // textFilter
            // 
            this.textFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFilter.Location = new System.Drawing.Point(286, 166);
            this.textFilter.Multiline = true;
            this.textFilter.Name = "textFilter";
            this.textFilter.Size = new System.Drawing.Size(42, 28);
            this.textFilter.TabIndex = 1;
            this.textFilter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textFilter.Click += new System.EventHandler(this.textFilter_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(208, 135);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(43, 24);
            this.label28.TabIndex = 2;
            this.label28.Text = "120";
            // 
            // textCappuchino
            // 
            this.textCappuchino.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCappuchino.Location = new System.Drawing.Point(286, 70);
            this.textCappuchino.Multiline = true;
            this.textCappuchino.Name = "textCappuchino";
            this.textCappuchino.Size = new System.Drawing.Size(42, 28);
            this.textCappuchino.TabIndex = 1;
            this.textCappuchino.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textCappuchino.Click += new System.EventHandler(this.textCappuchino_Click);
            this.textCappuchino.TextChanged += new System.EventHandler(this.textCappuchino_TextChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(214, 166);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(32, 24);
            this.label27.TabIndex = 2;
            this.label27.Text = "80";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(214, 71);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(32, 24);
            this.label26.TabIndex = 2;
            this.label26.Text = "70";
            // 
            // textLatte
            // 
            this.textLatte.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textLatte.Location = new System.Drawing.Point(286, 37);
            this.textLatte.Multiline = true;
            this.textLatte.Name = "textLatte";
            this.textLatte.Size = new System.Drawing.Size(42, 28);
            this.textLatte.TabIndex = 1;
            this.textLatte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textLatte.Click += new System.EventHandler(this.textLattle_Click);
            this.textLatte.TextChanged += new System.EventHandler(this.textLatte_TextChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(214, 102);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(32, 24);
            this.label25.TabIndex = 2;
            this.label25.Text = "90";
            // 
            // cheAffogato
            // 
            this.cheAffogato.AutoSize = true;
            this.cheAffogato.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheAffogato.Location = new System.Drawing.Point(8, 265);
            this.cheAffogato.Name = "cheAffogato";
            this.cheAffogato.Size = new System.Drawing.Size(97, 28);
            this.cheAffogato.TabIndex = 0;
            this.cheAffogato.Text = "Affogato";
            this.cheAffogato.UseVisualStyleBackColor = true;
            this.cheAffogato.CheckedChanged += new System.EventHandler(this.cheAffogato_CheckedChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(214, 38);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 24);
            this.label24.TabIndex = 2;
            this.label24.Text = "60";
            // 
            // cheMochaccion
            // 
            this.cheMochaccion.AutoSize = true;
            this.cheMochaccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheMochaccion.Location = new System.Drawing.Point(8, 136);
            this.cheMochaccion.Name = "cheMochaccion";
            this.cheMochaccion.Size = new System.Drawing.Size(133, 28);
            this.cheMochaccion.TabIndex = 0;
            this.cheMochaccion.Text = "Mochaccino";
            this.cheMochaccion.UseVisualStyleBackColor = true;
            this.cheMochaccion.CheckedChanged += new System.EventHandler(this.cheMochaccion_CheckedChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(214, 40);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(32, 24);
            this.label23.TabIndex = 2;
            this.label23.Text = "80";
            // 
            // cheFlat
            // 
            this.cheFlat.AutoSize = true;
            this.cheFlat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheFlat.Location = new System.Drawing.Point(8, 232);
            this.cheFlat.Name = "cheFlat";
            this.cheFlat.Size = new System.Drawing.Size(112, 28);
            this.cheFlat.TabIndex = 0;
            this.cheFlat.Text = "Flat White";
            this.cheFlat.UseVisualStyleBackColor = true;
            this.cheFlat.CheckedChanged += new System.EventHandler(this.cheFlat_CheckedChanged);
            // 
            // cheIrish
            // 
            this.cheIrish.AutoSize = true;
            this.cheIrish.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheIrish.Location = new System.Drawing.Point(8, 201);
            this.cheIrish.Name = "cheIrish";
            this.cheIrish.Size = new System.Drawing.Size(122, 28);
            this.cheIrish.TabIndex = 0;
            this.cheIrish.Text = "Irish Coffee";
            this.cheIrish.UseVisualStyleBackColor = true;
            this.cheIrish.CheckedChanged += new System.EventHandler(this.cheIrish_CheckedChanged);
            // 
            // cheEspresso
            // 
            this.cheEspresso.AutoSize = true;
            this.cheEspresso.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheEspresso.Location = new System.Drawing.Point(8, 105);
            this.cheEspresso.Name = "cheEspresso";
            this.cheEspresso.Size = new System.Drawing.Size(108, 28);
            this.cheEspresso.TabIndex = 0;
            this.cheEspresso.Text = "Espresso";
            this.cheEspresso.UseVisualStyleBackColor = true;
            this.cheEspresso.CheckedChanged += new System.EventHandler(this.cheEspresso_CheckedChanged);
            // 
            // cheFilter
            // 
            this.cheFilter.AutoSize = true;
            this.cheFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheFilter.Location = new System.Drawing.Point(8, 169);
            this.cheFilter.Name = "cheFilter";
            this.cheFilter.Size = new System.Drawing.Size(129, 28);
            this.cheFilter.TabIndex = 0;
            this.cheFilter.Text = "Filter Coffee";
            this.cheFilter.UseVisualStyleBackColor = true;
            this.cheFilter.CheckedChanged += new System.EventHandler(this.cheFilter_CheckedChanged);
            // 
            // cheCappuccino
            // 
            this.cheCappuccino.AutoSize = true;
            this.cheCappuccino.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheCappuccino.Location = new System.Drawing.Point(8, 73);
            this.cheCappuccino.Name = "cheCappuccino";
            this.cheCappuccino.Size = new System.Drawing.Size(131, 28);
            this.cheCappuccino.TabIndex = 0;
            this.cheCappuccino.Text = "Cappuccino";
            this.cheCappuccino.UseVisualStyleBackColor = true;
            this.cheCappuccino.CheckedChanged += new System.EventHandler(this.cheCappuccino_CheckedChanged);
            // 
            // cheLatte
            // 
            this.cheLatte.AutoSize = true;
            this.cheLatte.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheLatte.Location = new System.Drawing.Point(8, 41);
            this.cheLatte.Name = "cheLatte";
            this.cheLatte.Size = new System.Drawing.Size(68, 28);
            this.cheLatte.TabIndex = 0;
            this.cheLatte.Text = "Latte";
            this.cheLatte.UseVisualStyleBackColor = true;
            this.cheLatte.CheckedChanged += new System.EventHandler(this.cheLatte_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.textFrenchFries);
            this.panel3.Controls.Add(this.cheFrencFries);
            this.panel3.Controls.Add(this.textNachos);
            this.panel3.Controls.Add(this.cheCrispyBurger);
            this.panel3.Controls.Add(this.textClubSandwich);
            this.panel3.Controls.Add(this.textChickenFry);
            this.panel3.Controls.Add(this.cheClubSandwich);
            this.panel3.Controls.Add(this.textCrispyBurger);
            this.panel3.Controls.Add(this.cheBbqBurger);
            this.panel3.Controls.Add(this.textCheeseSandwich);
            this.panel3.Controls.Add(this.cheNachos);
            this.panel3.Controls.Add(this.textDelightBurger);
            this.panel3.Controls.Add(this.cheChickenDelighitBurger);
            this.panel3.Controls.Add(this.textBoxBbqBurger);
            this.panel3.Controls.Add(this.cheChickenFry);
            this.panel3.Controls.Add(this.cheCheeseSandwich);
            this.panel3.Location = new System.Drawing.Point(366, 95);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(370, 297);
            this.panel3.TabIndex = 2;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label22.Location = new System.Drawing.Point(286, 10);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(86, 24);
            this.label22.TabIndex = 3;
            this.label22.Text = "Quantity";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label21.Location = new System.Drawing.Point(224, 10);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(58, 24);
            this.label21.TabIndex = 3;
            this.label21.Text = "Price";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(20, 11);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(117, 24);
            this.label20.TabIndex = 3;
            this.label20.Text = "Others Item";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(236, 262);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 24);
            this.label19.TabIndex = 2;
            this.label19.Text = "40";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(236, 197);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 24);
            this.label17.TabIndex = 2;
            this.label17.Text = "65";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(236, 229);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(32, 24);
            this.label18.TabIndex = 2;
            this.label18.Text = "80";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(236, 134);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 24);
            this.label12.TabIndex = 2;
            this.label12.Text = "60";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(236, 165);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 24);
            this.label13.TabIndex = 2;
            this.label13.Text = "70";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(236, 70);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 24);
            this.label6.TabIndex = 2;
            this.label6.Text = "70";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(236, 102);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(32, 24);
            this.label11.TabIndex = 2;
            this.label11.Text = "70";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(236, 37);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "80";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(236, 39);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 24);
            this.label5.TabIndex = 2;
            this.label5.Text = "80";
            // 
            // textFrenchFries
            // 
            this.textFrenchFries.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFrenchFries.Location = new System.Drawing.Point(307, 261);
            this.textFrenchFries.Multiline = true;
            this.textFrenchFries.Name = "textFrenchFries";
            this.textFrenchFries.Size = new System.Drawing.Size(41, 28);
            this.textFrenchFries.TabIndex = 1;
            this.textFrenchFries.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textFrenchFries.Click += new System.EventHandler(this.textFrenchFries_Click);
            // 
            // cheFrencFries
            // 
            this.cheFrencFries.AutoSize = true;
            this.cheFrencFries.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheFrencFries.Location = new System.Drawing.Point(3, 262);
            this.cheFrencFries.Name = "cheFrencFries";
            this.cheFrencFries.Size = new System.Drawing.Size(137, 28);
            this.cheFrencFries.TabIndex = 0;
            this.cheFrencFries.Text = "French Fries";
            this.cheFrencFries.UseVisualStyleBackColor = true;
            this.cheFrencFries.CheckedChanged += new System.EventHandler(this.cheFrencFries_CheckedChanged);
            // 
            // textNachos
            // 
            this.textNachos.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNachos.Location = new System.Drawing.Point(307, 228);
            this.textNachos.Multiline = true;
            this.textNachos.Name = "textNachos";
            this.textNachos.Size = new System.Drawing.Size(41, 28);
            this.textNachos.TabIndex = 1;
            this.textNachos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textNachos.Click += new System.EventHandler(this.textNachos_Click);
            // 
            // cheCrispyBurger
            // 
            this.cheCrispyBurger.AutoSize = true;
            this.cheCrispyBurger.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheCrispyBurger.Location = new System.Drawing.Point(3, 102);
            this.cheCrispyBurger.Name = "cheCrispyBurger";
            this.cheCrispyBurger.Size = new System.Drawing.Size(143, 28);
            this.cheCrispyBurger.TabIndex = 0;
            this.cheCrispyBurger.Text = "Crispy Burger";
            this.cheCrispyBurger.UseVisualStyleBackColor = true;
            this.cheCrispyBurger.CheckedChanged += new System.EventHandler(this.cheCrispyBurger_CheckedChanged);
            // 
            // textClubSandwich
            // 
            this.textClubSandwich.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textClubSandwich.Location = new System.Drawing.Point(307, 134);
            this.textClubSandwich.Multiline = true;
            this.textClubSandwich.Name = "textClubSandwich";
            this.textClubSandwich.Size = new System.Drawing.Size(41, 28);
            this.textClubSandwich.TabIndex = 1;
            this.textClubSandwich.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textClubSandwich.Click += new System.EventHandler(this.textClubSandwich_Click);
            // 
            // textChickenFry
            // 
            this.textChickenFry.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textChickenFry.Location = new System.Drawing.Point(307, 197);
            this.textChickenFry.Multiline = true;
            this.textChickenFry.Name = "textChickenFry";
            this.textChickenFry.Size = new System.Drawing.Size(41, 28);
            this.textChickenFry.TabIndex = 1;
            this.textChickenFry.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textChickenFry.Click += new System.EventHandler(this.textChickenFry_Click);
            // 
            // cheClubSandwich
            // 
            this.cheClubSandwich.AutoSize = true;
            this.cheClubSandwich.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheClubSandwich.Location = new System.Drawing.Point(3, 134);
            this.cheClubSandwich.Name = "cheClubSandwich";
            this.cheClubSandwich.Size = new System.Drawing.Size(156, 28);
            this.cheClubSandwich.TabIndex = 0;
            this.cheClubSandwich.Text = "Club Sandwich";
            this.cheClubSandwich.UseVisualStyleBackColor = true;
            this.cheClubSandwich.CheckedChanged += new System.EventHandler(this.cheClubSandwich_CheckedChanged);
            // 
            // textCrispyBurger
            // 
            this.textCrispyBurger.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCrispyBurger.Location = new System.Drawing.Point(307, 101);
            this.textCrispyBurger.Multiline = true;
            this.textCrispyBurger.Name = "textCrispyBurger";
            this.textCrispyBurger.Size = new System.Drawing.Size(41, 28);
            this.textCrispyBurger.TabIndex = 1;
            this.textCrispyBurger.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textCrispyBurger.Click += new System.EventHandler(this.textCrispyBurger_Click);
            // 
            // cheBbqBurger
            // 
            this.cheBbqBurger.AutoSize = true;
            this.cheBbqBurger.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheBbqBurger.Location = new System.Drawing.Point(3, 37);
            this.cheBbqBurger.Name = "cheBbqBurger";
            this.cheBbqBurger.Size = new System.Drawing.Size(204, 28);
            this.cheBbqBurger.TabIndex = 0;
            this.cheBbqBurger.Text = "BBQ Chicken Burger";
            this.cheBbqBurger.UseVisualStyleBackColor = true;
            this.cheBbqBurger.CheckedChanged += new System.EventHandler(this.cheBbqBurger_CheckedChanged);
            // 
            // textCheeseSandwich
            // 
            this.textCheeseSandwich.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCheeseSandwich.Location = new System.Drawing.Point(307, 165);
            this.textCheeseSandwich.Multiline = true;
            this.textCheeseSandwich.Name = "textCheeseSandwich";
            this.textCheeseSandwich.Size = new System.Drawing.Size(41, 28);
            this.textCheeseSandwich.TabIndex = 1;
            this.textCheeseSandwich.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textCheeseSandwich.Click += new System.EventHandler(this.textCheeseSandwich_Click);
            // 
            // cheNachos
            // 
            this.cheNachos.AutoSize = true;
            this.cheNachos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheNachos.Location = new System.Drawing.Point(3, 228);
            this.cheNachos.Name = "cheNachos";
            this.cheNachos.Size = new System.Drawing.Size(94, 28);
            this.cheNachos.TabIndex = 0;
            this.cheNachos.Text = "Nachos";
            this.cheNachos.UseVisualStyleBackColor = true;
            this.cheNachos.CheckedChanged += new System.EventHandler(this.cheNachos_CheckedChanged);
            // 
            // textDelightBurger
            // 
            this.textDelightBurger.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDelightBurger.Location = new System.Drawing.Point(307, 69);
            this.textDelightBurger.Multiline = true;
            this.textDelightBurger.Name = "textDelightBurger";
            this.textDelightBurger.Size = new System.Drawing.Size(41, 28);
            this.textDelightBurger.TabIndex = 1;
            this.textDelightBurger.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textDelightBurger.Click += new System.EventHandler(this.textDelightBurger_Click);
            // 
            // cheChickenDelighitBurger
            // 
            this.cheChickenDelighitBurger.AutoSize = true;
            this.cheChickenDelighitBurger.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheChickenDelighitBurger.Location = new System.Drawing.Point(3, 70);
            this.cheChickenDelighitBurger.Name = "cheChickenDelighitBurger";
            this.cheChickenDelighitBurger.Size = new System.Drawing.Size(223, 28);
            this.cheChickenDelighitBurger.TabIndex = 0;
            this.cheChickenDelighitBurger.Text = "Chicken Delight Burger";
            this.cheChickenDelighitBurger.UseVisualStyleBackColor = true;
            this.cheChickenDelighitBurger.CheckedChanged += new System.EventHandler(this.cheChickenDelighitBurger_CheckedChanged);
            // 
            // textBoxBbqBurger
            // 
            this.textBoxBbqBurger.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxBbqBurger.Location = new System.Drawing.Point(307, 37);
            this.textBoxBbqBurger.Multiline = true;
            this.textBoxBbqBurger.Name = "textBoxBbqBurger";
            this.textBoxBbqBurger.Size = new System.Drawing.Size(41, 28);
            this.textBoxBbqBurger.TabIndex = 1;
            this.textBoxBbqBurger.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxBbqBurger.Click += new System.EventHandler(this.textBoxBbqBurger_Click);
            // 
            // cheChickenFry
            // 
            this.cheChickenFry.AutoSize = true;
            this.cheChickenFry.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheChickenFry.Location = new System.Drawing.Point(3, 197);
            this.cheChickenFry.Name = "cheChickenFry";
            this.cheChickenFry.Size = new System.Drawing.Size(130, 28);
            this.cheChickenFry.TabIndex = 0;
            this.cheChickenFry.Text = "Chicken Fry";
            this.cheChickenFry.UseVisualStyleBackColor = true;
            this.cheChickenFry.CheckedChanged += new System.EventHandler(this.cheChickenFry_CheckedChanged);
            // 
            // cheCheeseSandwich
            // 
            this.cheCheeseSandwich.AutoSize = true;
            this.cheCheeseSandwich.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheCheeseSandwich.Location = new System.Drawing.Point(3, 166);
            this.cheCheeseSandwich.Name = "cheCheeseSandwich";
            this.cheCheeseSandwich.Size = new System.Drawing.Size(183, 28);
            this.cheCheeseSandwich.TabIndex = 0;
            this.cheCheeseSandwich.Text = "Cheese Sandwich";
            this.cheCheeseSandwich.UseVisualStyleBackColor = true;
            this.cheCheeseSandwich.CheckedChanged += new System.EventHandler(this.cheCheeseSandwich_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Controls.Add(this.labelService);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.labelCostOthers);
            this.panel4.Controls.Add(this.labelCostDrinks);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Location = new System.Drawing.Point(6, 398);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(357, 154);
            this.panel4.TabIndex = 3;
            // 
            // labelService
            // 
            this.labelService.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelService.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelService.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelService.Location = new System.Drawing.Point(211, 101);
            this.labelService.Name = "labelService";
            this.labelService.Size = new System.Drawing.Size(124, 25);
            this.labelService.TabIndex = 0;
            this.labelService.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Service Charge";
            // 
            // labelCostOthers
            // 
            this.labelCostOthers.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelCostOthers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelCostOthers.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCostOthers.Location = new System.Drawing.Point(211, 62);
            this.labelCostOthers.Name = "labelCostOthers";
            this.labelCostOthers.Size = new System.Drawing.Size(124, 25);
            this.labelCostOthers.TabIndex = 0;
            this.labelCostOthers.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelCostOthers.Click += new System.EventHandler(this.labelCostOthers_Click);
            // 
            // labelCostDrinks
            // 
            this.labelCostDrinks.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelCostDrinks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelCostDrinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCostDrinks.Location = new System.Drawing.Point(211, 23);
            this.labelCostDrinks.Name = "labelCostDrinks";
            this.labelCostDrinks.Size = new System.Drawing.Size(124, 25);
            this.labelCostDrinks.TabIndex = 0;
            this.labelCostDrinks.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelCostDrinks.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "Cost Of Others";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Cost of Drinks";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.labelTotal);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.label14);
            this.panel5.Controls.Add(this.labelSubTotal);
            this.panel5.Controls.Add(this.labelTax);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Location = new System.Drawing.Point(366, 398);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(370, 154);
            this.panel5.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(-169, 101);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(70, 25);
            this.label16.TabIndex = 0;
            this.label16.Text = "label2";
            // 
            // labelTotal
            // 
            this.labelTotal.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(209, 100);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(124, 25);
            this.labelTotal.TabIndex = 0;
            this.labelTotal.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(-169, 62);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 25);
            this.label15.TabIndex = 0;
            this.label15.Text = "label2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(20, 99);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 25);
            this.label10.TabIndex = 0;
            this.label10.Text = "Total";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(-169, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 25);
            this.label14.TabIndex = 0;
            this.label14.Text = "label2";
            // 
            // labelSubTotal
            // 
            this.labelSubTotal.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelSubTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelSubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSubTotal.Location = new System.Drawing.Point(209, 61);
            this.labelSubTotal.Name = "labelSubTotal";
            this.labelSubTotal.Size = new System.Drawing.Size(124, 25);
            this.labelSubTotal.TabIndex = 0;
            this.labelSubTotal.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelTax
            // 
            this.labelTax.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTax.Location = new System.Drawing.Point(209, 22);
            this.labelTax.Name = "labelTax";
            this.labelTax.Size = new System.Drawing.Size(124, 25);
            this.labelTax.TabIndex = 0;
            this.labelTax.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 25);
            this.label9.TabIndex = 0;
            this.label9.Text = "SubTotal";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 25);
            this.label8.TabIndex = 0;
            this.label8.Text = "Tax";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel6.Controls.Add(this.toolStrip1);
            this.panel6.Controls.Add(this.rtfReceipt);
            this.panel6.Location = new System.Drawing.Point(739, 95);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(266, 406);
            this.panel6.TabIndex = 2;
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripButton,
            this.openToolStripButton,
            this.saveToolStripButton,
            this.printToolStripButton,
            this.toolStripSeparator,
            this.cutToolStripButton,
            this.copyToolStripButton,
            this.pasteToolStripButton,
            this.toolStripSeparator1,
            this.helpToolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(266, 27);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newToolStripButton
            // 
            this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripButton.Image")));
            this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripButton.Name = "newToolStripButton";
            this.newToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.newToolStripButton.Text = "&New";
            this.newToolStripButton.Click += new System.EventHandler(this.newToolStripButton_Click);
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripButton.Image")));
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.openToolStripButton.Text = "&Open";
            this.openToolStripButton.Click += new System.EventHandler(this.openToolStripButton_Click);
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.saveToolStripButton.Text = "&Save";
            this.saveToolStripButton.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // printToolStripButton
            // 
            this.printToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.printToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripButton.Image")));
            this.printToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripButton.Name = "printToolStripButton";
            this.printToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.printToolStripButton.Text = "&Print";
            this.printToolStripButton.Click += new System.EventHandler(this.printToolStripButton_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // cutToolStripButton
            // 
            this.cutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cutToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripButton.Image")));
            this.cutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripButton.Name = "cutToolStripButton";
            this.cutToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.cutToolStripButton.Text = "C&ut";
            this.cutToolStripButton.Click += new System.EventHandler(this.cutToolStripButton_Click);
            // 
            // copyToolStripButton
            // 
            this.copyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.copyToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripButton.Image")));
            this.copyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripButton.Name = "copyToolStripButton";
            this.copyToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.copyToolStripButton.Text = "&Copy";
            this.copyToolStripButton.Click += new System.EventHandler(this.copyToolStripButton_Click);
            // 
            // pasteToolStripButton
            // 
            this.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pasteToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripButton.Image")));
            this.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripButton.Name = "pasteToolStripButton";
            this.pasteToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.pasteToolStripButton.Text = "&Paste";
            this.pasteToolStripButton.Click += new System.EventHandler(this.pasteToolStripButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // helpToolStripButton
            // 
            this.helpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.helpToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripButton.Image")));
            this.helpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.helpToolStripButton.Name = "helpToolStripButton";
            this.helpToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.helpToolStripButton.Text = "He&lp";
            this.helpToolStripButton.Click += new System.EventHandler(this.helpToolStripButton_Click);
            // 
            // rtfReceipt
            // 
            this.rtfReceipt.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtfReceipt.Location = new System.Drawing.Point(3, 25);
            this.rtfReceipt.Multiline = true;
            this.rtfReceipt.Name = "rtfReceipt";
            this.rtfReceipt.Size = new System.Drawing.Size(261, 379);
            this.rtfReceipt.TabIndex = 0;
            this.rtfReceipt.TextChanged += new System.EventHandler(this.rtfReceipt_TextChanged);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel7.Controls.Add(this.buttonExit);
            this.panel7.Controls.Add(this.buttonRest);
            this.panel7.Controls.Add(this.buttonReceipt);
            this.panel7.Controls.Add(this.buttonTotal);
            this.panel7.Location = new System.Drawing.Point(739, 508);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(266, 45);
            this.panel7.TabIndex = 5;
            // 
            // buttonExit
            // 
            this.buttonExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(205, 11);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(57, 28);
            this.buttonExit.TabIndex = 0;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonRest
            // 
            this.buttonRest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRest.Location = new System.Drawing.Point(140, 11);
            this.buttonRest.Name = "buttonRest";
            this.buttonRest.Size = new System.Drawing.Size(61, 28);
            this.buttonRest.TabIndex = 0;
            this.buttonRest.Text = " Reset";
            this.buttonRest.UseVisualStyleBackColor = true;
            this.buttonRest.Click += new System.EventHandler(this.buttonRest_Click);
            // 
            // buttonReceipt
            // 
            this.buttonReceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReceipt.Location = new System.Drawing.Point(67, 11);
            this.buttonReceipt.Name = "buttonReceipt";
            this.buttonReceipt.Size = new System.Drawing.Size(70, 28);
            this.buttonReceipt.TabIndex = 0;
            this.buttonReceipt.Text = "Receipt";
            this.buttonReceipt.UseVisualStyleBackColor = true;
            this.buttonReceipt.Click += new System.EventHandler(this.buttonReceipt_Click);
            // 
            // buttonTotal
            // 
            this.buttonTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTotal.Location = new System.Drawing.Point(3, 11);
            this.buttonTotal.Name = "buttonTotal";
            this.buttonTotal.Size = new System.Drawing.Size(60, 27);
            this.buttonTotal.TabIndex = 0;
            this.buttonTotal.Text = "Total";
            this.buttonTotal.UseVisualStyleBackColor = true;
            this.buttonTotal.Click += new System.EventHandler(this.buttonTotal_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 557);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "bill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "bill";
            this.Load += new System.EventHandler(this.bill_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.CheckBox cheLatte;
        private System.Windows.Forms.CheckBox cheAffogato;
        private System.Windows.Forms.CheckBox cheMochaccion;
        private System.Windows.Forms.CheckBox cheFlat;
        private System.Windows.Forms.CheckBox cheIrish;
        private System.Windows.Forms.CheckBox cheEspresso;
        private System.Windows.Forms.CheckBox cheFilter;
        private System.Windows.Forms.CheckBox cheCappuccino;
        private System.Windows.Forms.CheckBox cheFrencFries;
        private System.Windows.Forms.CheckBox cheCrispyBurger;
        private System.Windows.Forms.CheckBox cheClubSandwich;
        private System.Windows.Forms.CheckBox cheBbqBurger;
        private System.Windows.Forms.CheckBox cheNachos;
        private System.Windows.Forms.CheckBox cheChickenDelighitBurger;
        private System.Windows.Forms.CheckBox cheChickenFry;
        private System.Windows.Forms.CheckBox cheCheeseSandwich;
        private System.Windows.Forms.Label labelService;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelCostOthers;
        private System.Windows.Forms.Label labelCostDrinks;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labelSubTotal;
        private System.Windows.Forms.Label labelTax;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textAffogato;
        private System.Windows.Forms.TextBox textFlat;
        private System.Windows.Forms.TextBox textMochaccino;
        private System.Windows.Forms.TextBox textIrish;
        private System.Windows.Forms.TextBox textEspresso;
        private System.Windows.Forms.TextBox textFilter;
        private System.Windows.Forms.TextBox textCappuchino;
        private System.Windows.Forms.TextBox textLatte;
        private System.Windows.Forms.TextBox textFrenchFries;
        private System.Windows.Forms.TextBox textNachos;
        private System.Windows.Forms.TextBox textClubSandwich;
        private System.Windows.Forms.TextBox textChickenFry;
        private System.Windows.Forms.TextBox textCrispyBurger;
        private System.Windows.Forms.TextBox textCheeseSandwich;
        private System.Windows.Forms.TextBox textDelightBurger;
        private System.Windows.Forms.TextBox textBoxBbqBurger;
        private System.Windows.Forms.TextBox rtfReceipt;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonRest;
        private System.Windows.Forms.Button buttonReceipt;
        private System.Windows.Forms.Button buttonTotal;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton newToolStripButton;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripButton printToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton cutToolStripButton;
        private System.Windows.Forms.ToolStripButton copyToolStripButton;
        private System.Windows.Forms.ToolStripButton pasteToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton helpToolStripButton;
        private System.Windows.Forms.Timer timer1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button buttonBack;
    }
}